module.exports = {
    apps: [
      {
        name: 'web-dashboard-backend',
        script: 'app.js',
        cwd: 'C:/Users/Administrator/Desktop/web-dashboard/backend',
        env: {
          NODE_ENV: 'production',
          PORT: 5000
        }
      }
    ]
  };
  