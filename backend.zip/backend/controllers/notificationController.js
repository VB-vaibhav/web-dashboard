const db = require('../config/db');

exports.generateExpiryNotifications = async (req, res) => {
    try {
        const now = new Date();
        const threeDaysLater = new Date();
        threeDaysLater.setDate(now.getDate() + 3);

        const [clients] = await db.promise().query(`
            SELECT c.id AS client_id, c.client_name, c.service, c.expiry_date, c.logical_client_id,
                   u.id AS user_id, u.role
            FROM clients c
            JOIN users u ON (
                u.role = 'superadmin'
                OR (
                    u.role = 'admin'
                    AND NOT EXISTS (
                        SELECT 1 FROM client_admin_exclusions e
                        WHERE e.logical_client_id = c.logical_client_id AND e.admin_id = u.id
                    )
                )
                OR (
                    u.role = 'middleman'
                    AND c.middleman_name = u.username
                )
            )
            WHERE c.expiry_date <= ?
            AND (c.is_deleted = 0 OR c.is_deleted IS NULL)
            AND (c.is_cancelled = 0 OR c.is_cancelled IS NULL)
        `, [threeDaysLater]);

        let insertedCount = 0;

        for (const row of clients) {
            try {
                if (!row || !row.expiry_date || !row.client_id || !row.user_id || !row.service) {
                    console.warn("⚠️ Incomplete row, skipping:", row);
                    continue;
                }

                const expiryDate = new Date(row.expiry_date);
                const statusText = expiryDate < now ? 'Expired' : 'Expiring in 3 days';
                console.log(statusText);

                const [existingRows] = await db.promise().query(`
                    SELECT id FROM notifications 
                    WHERE client_id = ? AND user_id = ? AND status = ? AND ignored = 0
                `, [row.client_id, row.user_id, statusText]);

                // Only insert if no existing record found
                if (!existingRows || existingRows.length === 0) {
                    await db.promise().query(`
                        INSERT INTO notifications (client_id, user_id, status, sent_at, service, expiry_date)
                        VALUES (?, ?, ?, NOW(), ?, ?)
                    `, [row.client_id, row.user_id, statusText, row.service, row.expiry_date]);

                    insertedCount++;
                }
            } catch (innerErr) {
                console.error("❌ Error inside loop:", innerErr.message || innerErr);
            }
        }
        // res.status(200).json({ message: `Notifications generated. (${insertedCount} inserted)` });
    } catch (err) {
        console.error("❌ Notification generation failed:", err.message || err);
        res.status(500).json({ error: 'Server error during notification generation.' });
    }
};

// const notificationQueue = require('../queues/notificationQueue');

// exports.generateExpiryNotifications = async (req, res) => {
//     try {
//         const now = new Date();
//         const threeDaysLater = new Date();
//         threeDaysLater.setDate(now.getDate() + 3);

//         await notificationQueue.add('generate', {
//             now,
//             threeDaysLater
//         });

//         res.status(202).json({ message: 'Notification job enqueued. Will process shortly.' });
//     } catch (err) {
//         console.error("❌ Failed to enqueue notification job:", err);
//         res.status(500).json({ error: 'Failed to start background notification generation.' });
//     }
// };


exports.getNotifications = async (req, res) => {
    try {
        const userId = req.user.id;
        const role = req.user.role;
        const username = req.user.username;

        let query = `
            SELECT n.*, c.client_name 
            FROM notifications n 
            JOIN clients c ON n.client_id = c.id 
            WHERE n.user_id = ? AND n.ignored = 0
        `;

        // Admins: exclude clients excluded for them
        if (role === 'admin') {
            query += `
              AND NOT EXISTS (
                SELECT 1 FROM client_admin_exclusions e
                WHERE e.logical_client_id = c.logical_client_id AND e.admin_id = ?
              )
            `;
        }

        // Middleman: show only their clients
        if (role === 'middleman') {
            query += ` AND c.middleman_name = (SELECT username FROM users WHERE id = ?)`;
        }

        query += ` ORDER BY n.sent_at DESC`;

        let values = [userId];
        if (role === 'admin') values.push(userId);
        if (role === 'middleman') values.push(userId);

        const [rows] = await db.promise().query(query, values);
        res.json(rows);
    } catch (err) {
        console.error("❌ Failed to fetch notifications:", err.message || err);
        res.status(500).send("Failed to fetch notifications.");
    }
};


exports.ignoreNotification = async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;
    await db.promise().query(
        `UPDATE notifications SET ignored = 1 WHERE id = ? AND user_id = ?`,
        [id, userId]
    );
    res.send({ success: true });
};

// Get notification count
exports.getNotificationCount = async (req, res) => {
    try {
      const userId = req.user.id;
      const [rows] = await db.promise().query(
        `SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND ignored = 0`,
        [userId]
      );
      res.json({ count: rows[0].count });
    } catch (err) {
      console.error("❌ Failed to get notification count:", err.message || err);
      res.status(500).json({ error: 'Failed to fetch notification count' });
    }
  };
  