const db = require('../config/db');
const { getDateRangeForFilter } = require('../utils/dateUtils'); // You need to create this helper
const moment = require('moment');

const dayjs = require('dayjs');
const axios = require('axios');

exports.getClients = (req, res) => {
  const { role, id: userId } = req.user;
  const { service, dateFilter, from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  let sql = '';
  const params = [];

  let dateFrom = from;
  let dateTo = to;

  // If `from` and `to` are not passed, use range from dateFilter
  if (!from || !to) {
    const range = getDateRangeForFilter(dateFilter);
    if (range.start && range.end) {
      dateFrom = range.start;
      dateTo = range.end;
    }
  }

  // Build base query based on role
  if (role === 'superadmin') {
    sql = `SELECT * FROM clients WHERE is_cancelled = FALSE AND is_deleted = 0`;

    if (service && service !== 'all') {
      sql += ` AND service = ?`;
      params.push(service);
    }

    if (dateFrom && dateTo) {
      sql += ` AND DATE(start_date) BETWEEN ? AND ?`;
      params.push(dateFrom, dateTo);
    }

  } else {
    sql = `
      SELECT c.* FROM clients c
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = FALSE AND c.is_deleted = 0 AND e.id IS NULL
    `;
    params.push(userId);

    if (service && service !== 'all') {
      sql += ` AND c.service = ?`;
      params.push(service);
    }

    if (dateFrom && dateTo) {
      sql += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
      params.push(dateFrom, dateTo);
    }

    if (role === 'middleman') {
      sql += ` AND c.middleman_name = (SELECT username FROM users WHERE id = ?)`;
      params.push(userId);
    }
  }

  // Count total records before applying pagination
  const countSql = `SELECT COUNT(*) AS total FROM (${sql}) AS count_alias`;

  db.query(countSql, params, (countErr, countResult) => {
    if (countErr) {
      return res.status(500).json({ error: 'Count query failed', details: countErr });
    }

    const total = countResult[0]?.total || 0;

    // Apply pagination to original SQL
    const paginatedSql = `${sql} LIMIT ? OFFSET ?`;
    const paginatedParams = [...params, parsedLimit, offset];

    db.query(paginatedSql, paginatedParams, (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Client fetch error', details: err });
      }

      res.json({
        clients: results,
        total,
        page: parsedPage,
        limit: parsedLimit
      });
    });
  });
};

// exports.addClient = (req, res) => {
//   const client = req.body;
//   const fields = Object.keys(client).join(", ");
//   const values = Object.values(client);
//   const placeholders = values.map(() => "?").join(", ");

//   const sql = `INSERT INTO clients (${fields}) VALUES (${placeholders})`;

//   db.query(sql, values, (err, result) => {
//     if (err) return res.status(500).json({ error: "Insert failed", details: err });

//     if (client.middleman_name) {
//       updateMiddlemanServiceFlags(client.middleman_name);
//     }

//     res.status(201).json({ id: result.insertId });
//   });
// };

// Get Cloud Server (VPS) Clients


// exports.getCloudClients = async (req, res) => {
//   const { role, id: userId } = req.user;
//   const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

//   const parsedPage = parseInt(page);
//   const parsedLimit = parseInt(limit);
//   const offset = (parsedPage - 1) * parsedLimit;

//   const dateRange = getDateRangeForFilter(dateFilter);
//   const dateFrom = from || dateRange.start;
//   const dateTo = to || dateRange.end;

//   let baseSelect = `
//     SELECT c.*
//   `;

//   if (role !== 'middleman') {
//     baseSelect += `, c.middleman_name, c.paid_to`;
//   }

//   let baseQuery = '';
//   const params = [];

//   if (role === 'superadmin') {
//     baseQuery = `
//       FROM clients c
//       WHERE c.is_cancelled = 0 AND c.is_deleted = 0 AND c.service = 'vps'
//     `;
//     if (dateFrom && dateTo) {
//       baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
//       params.push(dateFrom, dateTo);
//     }

//   } else {
//     baseQuery = `
//       FROM clients c
//       LEFT JOIN client_admin_exclusions e ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
//       WHERE c.is_cancelled = 0 AND c.is_deleted = 0 AND c.service = 'vps' AND e.id IS NULL
//     `;
//     params.push(userId);

//     if (dateFrom && dateTo) {
//       baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
//       params.push(dateFrom, dateTo);
//     }

//     if (role === 'middleman') {
//       baseQuery += ` AND c.middleman_name = (SELECT username FROM users WHERE id = ?)`;
//       params.push(userId);
//     }
//   }

//   const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
//   const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
//   const paginatedParams = [...params, parsedLimit, offset];

//   try {
//     const [countResult] = await db.promise().query(countSql, params);
//     const total = countResult[0]?.total || 0;

//     const [results] = await db.promise().query(paginatedSql, paginatedParams);

//     res.json({
//       clients: results,
//       total,
//       page: parsedPage,
//       limit: parsedLimit
//     });
//   } catch (err) {
//     console.error('Error fetching cloud clients:', err);
//     res.status(500).json({ error: 'Failed to fetch cloud clients' });
//   }
// };
exports.getCloudClients = async (req, res) => {
  const { role, id: userId } = req.user;
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  const dateRange = getDateRangeForFilter(dateFilter);
  const dateFrom = from || dateRange.start;
  const dateTo = to || dateRange.end;

  let baseSelect = `SELECT c.*`;
  if (role !== 'middleman') {
    baseSelect += `, c.middleman_name, c.paid_to`;
  }

  let baseQuery = `FROM clients c `;
  const params = [];

  // 🟩 Role: Admin (exclude excluded clients)
  if (role === 'admin') {
    baseQuery += `
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'vps' AND e.id IS NULL
    `;
    params.push(userId);
  }

  // 🟩 Role: Middleman (only his clients)
  else if (role === 'middleman') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'vps' 
      AND c.middleman_name = (SELECT username FROM users WHERE id = ?)
    `;
    params.push(userId);
  }

  // 🟩 Role: Superadmin (see all)
  else if (role === 'superadmin') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'vps'
    `;
  }

  // 🗓️ Apply date filter
  if (dateFrom && dateTo) {
    baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
    params.push(dateFrom, dateTo);
  }

  const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
  const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
  const paginatedParams = [...params, parsedLimit, offset];

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    const [results] = await db.promise().query(paginatedSql, paginatedParams);

    res.json({
      clients: results,
      total,
      page: parsedPage,
      limit: parsedLimit
    });
  } catch (err) {
    console.error('Error fetching cloud clients:', err);
    res.status(500).json({ error: 'Failed to fetch cloud clients' });
  }
};

exports.getCerberusClients = async (req, res) => {
  const { role, id: userId } = req.user;
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  const dateRange = getDateRangeForFilter(dateFilter);
  const dateFrom = from || dateRange.start;
  const dateTo = to || dateRange.end;

  let baseSelect = `SELECT c.*`;
  if (role !== 'middleman') {
    baseSelect += `, c.middleman_name, c.paid_to`;
  }

  let baseQuery = `FROM clients c `;
  const params = [];

  // 🟩 Role: Admin (exclude excluded clients)
  if (role === 'admin') {
    baseQuery += `
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'cerberus' AND e.id IS NULL
    `;
    params.push(userId);
  }

  // 🟩 Role: Middleman (only his clients)
  else if (role === 'middleman') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'cerberus' 
      AND c.middleman_name = (SELECT username FROM users WHERE id = ?)
    `;
    params.push(userId);
  }

  // 🟩 Role: Superadmin (see all)
  else if (role === 'superadmin') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'cerberus'
    `;
  }

  // 🗓️ Apply date filter
  if (dateFrom && dateTo) {
    baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
    params.push(dateFrom, dateTo);
  }

  const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
  const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
  const paginatedParams = [...params, parsedLimit, offset];

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    const [results] = await db.promise().query(paginatedSql, paginatedParams);

    res.json({
      clients: results,
      total,
      page: parsedPage,
      limit: parsedLimit
    });
  } catch (err) {
    console.error('Error fetching cerberus clients:', err);
    res.status(500).json({ error: 'Failed to fetch cerberus clients' });
  }
};


// exports.getProxyClients = async (req, res) => {
//   const { role, id: userId } = req.user;
//   const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

//   const parsedPage = parseInt(page);
//   const parsedLimit = parseInt(limit);
//   const offset = (parsedPage - 1) * parsedLimit;

//   const dateRange = getDateRangeForFilter(dateFilter);
//   const dateFrom = from || dateRange.start;
//   const dateTo = to || dateRange.end;

//   let baseSelect = `
//     SELECT c.*
//   `;

//   if (role !== 'middleman') {
//     baseSelect += `, c.middleman_name, c.paid_to`;
//   }

//   let baseQuery = '';
//   const params = [];

//   if (role === 'superadmin') {
//     baseQuery = `
//       FROM clients c
//       WHERE c.is_cancelled = 0 AND c.is_deleted = 0 AND c.service = 'proxy'
//     `;
//     if (dateFrom && dateTo) {
//       baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
//       params.push(dateFrom, dateTo);
//     }

//   } else {
//     baseQuery = `
//       FROM clients c
//       LEFT JOIN client_admin_exclusions e ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
//       WHERE c.is_cancelled = 0 AND c.is_deleted = 0 AND c.service = 'proxy' AND e.id IS NULL
//     `;
//     params.push(userId);

//     if (dateFrom && dateTo) {
//       baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
//       params.push(dateFrom, dateTo);
//     }

//     if (role === 'middleman') {
//       baseQuery += ` AND c.middleman_name = (SELECT username FROM users WHERE id = ?)`;
//       params.push(userId);
//     }
//     // else if (role === 'admin') {
//     //   baseQuery += ` AND c.logical_client_id NOT IN (SELECT logical_client_id FROM client_admin_exclusions WHERE admin_id = ?)`;
//     //   params.push(userId);
//     // }
//   }

//   const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
//   const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
//   const paginatedParams = [...params, parsedLimit, offset];

//   try {
//     const [countResult] = await db.promise().query(countSql, params);
//     const total = countResult[0]?.total || 0;

//     const [results] = await db.promise().query(paginatedSql, paginatedParams);

//     res.json({
//       clients: results,
//       total,
//       page: parsedPage,
//       limit: parsedLimit
//     });
//   } catch (err) {
//     console.error('Error fetching cloud clients:', err);
//     res.status(500).json({ error: 'Failed to fetch cloud clients' });
//   }
// };

// ✅ PUT /clients/:id


// exports.updateClient = (req, res) => {
//   const { id } = req.params;
//   const client = req.body;

//   // Fetch old middleman/service to compare later
//   db.query("SELECT middleman_name FROM clients WHERE id = ?", [id], (err, oldResult) => {
//     if (err || oldResult.length === 0) return res.status(404).json({ error: "Client not found" });

//     const oldMiddleman = oldResult[0].middleman_name;

//     const updates = Object.keys(client).map(field => `${field} = ?`).join(", ");
//     const values = [...Object.values(client), id];
//     const sql = `UPDATE clients SET ${updates} WHERE id = ?`;

//     db.query(sql, values, (err2) => {
//       if (err2) return res.status(500).json({ error: "Update failed", details: err2 });

//       if (client.middleman_name) {
//         updateMiddlemanServiceFlags(client.middleman_name);
//         if (client.middleman_name !== oldMiddleman) {
//           updateMiddlemanServiceFlags(oldMiddleman);
//         }
//       }

//       res.json({ message: "Client updated" });
//     });
//   });
// };


exports.getProxyClients = async (req, res) => {
  const { role, id: userId } = req.user;
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  const dateRange = getDateRangeForFilter(dateFilter);
  const dateFrom = from || dateRange.start;
  const dateTo = to || dateRange.end;

  let baseSelect = `SELECT c.*`;
  if (role !== 'middleman') {
    baseSelect += `, c.middleman_name, c.paid_to`;
  }

  let baseQuery = `FROM clients c `;
  const params = [];

  // 🟩 Role: Admin (exclude excluded clients)
  if (role === 'admin') {
    baseQuery += `
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'proxy' AND e.id IS NULL
    `;
    params.push(userId);
  }

  // 🟩 Role: Middleman (only his clients)
  else if (role === 'middleman') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'proxy' 
      AND c.middleman_name = (SELECT username FROM users WHERE id = ?)
    `;
    params.push(userId);
  }

  // 🟩 Role: Superadmin (see all)
  else if (role === 'superadmin') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'proxy'
    `;
  }

  // 🗓️ Apply date filter
  if (dateFrom && dateTo) {
    baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
    params.push(dateFrom, dateTo);
  }

  const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
  const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
  const paginatedParams = [...params, parsedLimit, offset];

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    const [results] = await db.promise().query(paginatedSql, paginatedParams);

    res.json({
      clients: results,
      total,
      page: parsedPage,
      limit: parsedLimit
    });
  } catch (err) {
    console.error('Error fetching proxy clients:', err);
    res.status(500).json({ error: 'Failed to fetch proxy clients' });
  }
};

exports.getStorageClients = async (req, res) => {
  const { role, id: userId } = req.user;
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  const dateRange = getDateRangeForFilter(dateFilter);
  const dateFrom = from || dateRange.start;
  const dateTo = to || dateRange.end;

  let baseSelect = `SELECT c.*`;
  if (role !== 'middleman') {
    baseSelect += `, c.middleman_name, c.paid_to`;
  }

  let baseQuery = `FROM clients c `;
  const params = [];

  // 🟩 Role: Admin (exclude excluded clients)
  if (role === 'admin') {
    baseQuery += `
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'storage' AND e.id IS NULL
    `;
    params.push(userId);
  }

  // 🟩 Role: Middleman (only his clients)
  else if (role === 'middleman') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'storage' 
      AND c.middleman_name = (SELECT username FROM users WHERE id = ?)
    `;
    params.push(userId);
  }

  // 🟩 Role: Superadmin (see all)
  else if (role === 'superadmin') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'storage'
    `;
  }

  // 🗓️ Apply date filter
  if (dateFrom && dateTo) {
    baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
    params.push(dateFrom, dateTo);
  }

  const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
  const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
  const paginatedParams = [...params, parsedLimit, offset];

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    const [results] = await db.promise().query(paginatedSql, paginatedParams);

    res.json({
      clients: results,
      total,
      page: parsedPage,
      limit: parsedLimit
    });
  } catch (err) {
    console.error('Error fetching storage clients:', err);
    res.status(500).json({ error: 'Failed to fetch storage clients' });
  }
};

exports.getVarysClients = async (req, res) => {
  const { role, id: userId } = req.user;
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const offset = (parsedPage - 1) * parsedLimit;

  const dateRange = getDateRangeForFilter(dateFilter);
  const dateFrom = from || dateRange.start;
  const dateTo = to || dateRange.end;

  let baseSelect = `SELECT c.*`;
  if (role !== 'middleman') {
    baseSelect += `, c.middleman_name, c.paid_to`;
  }

  let baseQuery = `FROM clients c `;
  const params = [];

  // 🟩 Role: Admin (exclude excluded clients)
  if (role === 'admin') {
    baseQuery += `
      LEFT JOIN client_admin_exclusions e 
      ON c.logical_client_id = e.logical_client_id AND e.admin_id = ?
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'varys' AND e.id IS NULL
    `;
    params.push(userId);
  }

  // 🟩 Role: Middleman (only his clients)
  else if (role === 'middleman') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'varys' 
      AND c.middleman_name = (SELECT username FROM users WHERE id = ?)
    `;
    params.push(userId);
  }

  // 🟩 Role: Superadmin (see all)
  else if (role === 'superadmin') {
    baseQuery += `
      WHERE c.is_cancelled = 0 AND c.is_deleted = 0 
      AND c.service = 'varys'
    `;
  }

  // 🗓️ Apply date filter
  if (dateFrom && dateTo) {
    baseQuery += ` AND DATE(c.start_date) BETWEEN ? AND ?`;
    params.push(dateFrom, dateTo);
  }

  const countSql = `SELECT COUNT(*) AS total ${baseQuery}`;
  const paginatedSql = `${baseSelect} ${baseQuery} LIMIT ? OFFSET ?`;
  const paginatedParams = [...params, parsedLimit, offset];

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    const [results] = await db.promise().query(paginatedSql, paginatedParams);

    res.json({
      clients: results,
      total,
      page: parsedPage,
      limit: parsedLimit
    });
  } catch (err) {
    console.error('Error fetching varys clients:', err);
    res.status(500).json({ error: 'Failed to fetch varys clients' });
  }
};

exports.updateClient = (req, res) => {
  const { id } = req.params;
  const clientUpdates = req.body;

  // Fetch current client data
  db.query("SELECT * FROM clients WHERE id = ?", [id], (err, oldResult) => {
    if (err || oldResult.length === 0) {
      return res.status(404).json({ error: "Client not found" });
    }

    const existingClient = oldResult[0];
    const oldMiddleman = existingClient.middleman_name;

    // Determine updated price and amount_paid
    const updatedPrice = clientUpdates.price !== undefined ? parseFloat(clientUpdates.price) : parseFloat(existingClient.price || 0);
    const updatedPaid = clientUpdates.amount_paid !== undefined ? parseFloat(clientUpdates.amount_paid) : parseFloat(existingClient.amount_paid || 0);

    // If either price or amount_paid is updated, recalculate
    if ('price' in clientUpdates || 'amount_paid' in clientUpdates) {
      const amount_due = updatedPrice - updatedPaid;
      let payment_status = 'unpaid';
      if (amount_due === 0) payment_status = 'paid';
      else if (amount_due < updatedPrice) payment_status = 'partially paid';

      clientUpdates.amount_due = amount_due;
      clientUpdates.payment_status = payment_status;
    }

    if ('is_cancelled' in clientUpdates && clientUpdates.is_cancelled === 1) {
      clientUpdates.cancelled_on = new Date(); // This sets current date
    }

    const updates = Object.keys(clientUpdates).map(field => `${field} = ?`).join(", ");
    const values = [...Object.values(clientUpdates), id];
    const sql = `UPDATE clients SET ${updates} WHERE id = ?`;

    db.query(sql, values, (err2) => {
      if (err2) return res.status(500).json({ error: "Update failed", details: err2 });

      if (clientUpdates.middleman_name) {
        updateMiddlemanServiceFlags(clientUpdates.middleman_name);
        if (clientUpdates.middleman_name !== oldMiddleman) {
          updateMiddlemanServiceFlags(oldMiddleman);
        }
      }

      res.json({ message: "Client updated" });
    });
  });
};


// ✅ DELETE /clients/:id
// exports.deleteClient = (req, res) => {
//   const { id } = req.params;

//   db.query("SELECT middleman_name FROM clients WHERE id = ?", [id], (err, result) => {
//     if (err || result.length === 0) return res.status(404).json({ error: "Client not found" });

//     const middlemanName = result[0].middleman_name;

//     const sql = "UPDATE clients SET is_cancelled = TRUE WHERE id = ?";
//     db.query(sql, [id], (err2) => {
//       if (err2) return res.status(500).json({ error: "Delete failed" });

//       updateMiddlemanServiceFlags(middlemanName);
//       res.json({ message: "Client cancelled" });
//     });
//   });
// };

exports.deleteClient = async (req, res) => {
  const { id } = req.params;

  try {
    // 1. Fetch the client to get logical_client_id and middleman
    const [rows] = await db.promise().query("SELECT logical_client_id, middleman_name FROM clients WHERE id = ?", [id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Client not found" });
    }

    const { logical_client_id, middleman_name } = rows[0];

    // 2. Perform soft delete
    await db.promise().query("UPDATE clients SET is_deleted = 1, deleted_on = CURDATE() WHERE id = ?", [id]);

    // 3. Update middleman's service flags if needed
    updateMiddlemanServiceFlags(middleman_name);

    res.json({ message: "Client deleted", logical_client_id });
  } catch (err) {
    console.error("❌ Error deleteing client:", err.message);
    res.status(500).json({ error: "Delete failed" });
  }
};



// ✅ Update middleman's visibility flags based on current clients
// function updateMiddlemanServiceFlags(middlemanName) {
//   const flagValue = results[0].count > 0 ? 1 : 0;
//   const updateSql = `UPDATE users SET is_${service} = ? WHERE username = ?`;

//   const services = ['vps', 'cerberus', 'proxy', 'storage', 'varys'];

//   services.forEach(service => {
//     const checkSql = `
//           SELECT COUNT(*) AS count FROM clients
//           WHERE service = ? AND middleman_name = ? AND is_cancelled = FALSE
//         `;

//     db.query(checkSql, [service, middlemanName], (err, results) => {
//       if (!err) {
//         const flagValue = results[0].count > 0 ? 1 : 0;
//         const updateSql = `UPDATE users SET is_${service} = ? WHERE username = ?`;
//         db.query(updateSql, [flagValue, middlemanName]);
//       }
//     });
//   });
// }

// Utility to dynamically update middleman service flags
function updateMiddlemanServiceFlags(middlemanName) {
  const services = ['vps', 'cerberus', 'proxy', 'storage', 'varys'];

  services.forEach(service => {
    const checkSql = `
      SELECT COUNT(*) AS count FROM clients
      WHERE service = ? AND middleman_name = ? AND is_cancelled = FALSE
    `;

    db.query(checkSql, [service, middlemanName], (err, results) => {
      if (!err) {
        const flagValue = results[0].count > 0 ? 1 : 0;
        const updateSql = `UPDATE users SET is_${service} = ? WHERE username = ?`;
        db.query(updateSql, [flagValue, middlemanName]);
      }
    });
  });
}

// clientController.js
// exports.getClientNames = (req, res) => {
//   const sql = `SELECT DISTINCT client_name FROM clients WHERE client_name IS NOT NULL`;

//   db.query(sql, (err, results) => {
//     if (err) return res.status(500).json({ error: 'DB Error' });
//     const names = results.map(r => r.client_name);
//     res.json(names);
//   });
// };

// exports.getServices = (req, res) => {
//   db.query("SELECT id, name, service_key FROM services", (err, results) => {
//     if (err) return res.status(500).json({ error: 'Failed to fetch services' });
//     res.json(results);
//   });
// };


exports.getClientNames = async (req, res) => {
  console.log("🟨 Called /clients/names");
  console.log("🔐 req.user =", req.user);

  try {
    const [rows] = await db.promise().query("SELECT DISTINCT logical_client_id, client_name, email_or_phone FROM clients WHERE is_cancelled = 0  AND is_deleted = 0"); // ✅ FIXED
    // res.json(rows.map(r => r.client_name));
    res.json(rows);
  } catch (err) {
    console.error('Error fetching client names:', err.message);
    res.status(400).json({ error: 'Could not fetch client names' });
  }
};
// exports.getServices = async (req, res) => {
//   console.log("🟨 Called /clients/services");
//   console.log("🔐 req.user =", req.user);

//   try {
//     const [rows] = await db.promise().query("SELECT id, name, service_key FROM services"); // ✅ FIXED
//     res.json(rows);
//   } catch (err) {
//     console.error('Error fetching services:', err.message);
//     res.status(400).json({ error: 'Could not fetch services' });
//   }
// };

exports.getServices = async (req, res) => {
  console.log("🟨 Called /clients/services");
  console.log("🔐 req.user =", req.user);

  try {
    if (!req.user) {
      return res.status(400).json({ error: "User context missing" });
    }

    const role = req.user.role;

    if (role === 'superadmin') {
      const [rows] = await db.promise().query("SELECT id, name, service_key FROM services");
      return res.json(rows);
    }

    if (role === 'admin') {
      // Step 1: Fetch service visibility flags from `users` table
      const [adminRes] = await db.promise().query(
        `SELECT is_cerberus, is_vps, is_proxy, is_storage, is_varys FROM users WHERE id = ?`,
        [req.user.id]
      );

      const admin = adminRes[0];
      if (!admin) return res.status(404).json({ error: "Admin not found" });

      // Step 2: Build list of excluded service keys based on 0 values
      const excludedKeys = [];
      if (admin.is_cerberus === 0) excludedKeys.push('cerberus');
      if (admin.is_vps === 0) excludedKeys.push('vps');
      if (admin.is_proxy === 0) excludedKeys.push('proxy');
      if (admin.is_storage === 0) excludedKeys.push('storage');
      if (admin.is_varys === 0) excludedKeys.push('varys');

      // Step 3: Fetch allowed services
      const query = excludedKeys.length
        ? `SELECT id, name, service_key FROM services WHERE service_key NOT IN (${excludedKeys.map(() => '?').join(',')})`
        : "SELECT id, name, service_key FROM services";

      const [services] = await db.promise().query(query, excludedKeys);
      return res.json(services);
    }

    return res.status(403).json({ error: "Middleman not allowed" });
  } catch (err) {
    console.error('Error fetching services:', err.message);
    return res.status(400).json({ error: 'Could not fetch services' });
  }
};



exports.getServicePlans = (req, res) => {
  const { serviceId } = req.params;
  db.query("SELECT name FROM plans WHERE service_id = ?", [serviceId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch plans' });
    res.json(rows);
  });
};

exports.addPlan = (req, res) => {
  // console.log("Plan triggered");  
  const { name, service_id } = req.body;
  if (!name || !service_id) {
    return res.status(400).json({ error: 'Missing plan name or service ID' });
  }

  const sql = "INSERT INTO plans (name, service_id) VALUES (?, ?)";
  db.query(sql, [name, service_id], (err, result) => {
    if (err) {
      console.error('Error inserting plan:', err.message);
      return res.status(500).json({ error: 'Failed to add plan' });
    }

    res.status(201).json({ message: 'Plan added successfully', id: result.insertId });
  });
};

const columnMap = {
  'Client Name': 'client_name',
  'Email/Number': 'email_or_phone',
  'Middleman Name': 'middleman_name',
  'Start Date': 'start_date',
  'Expiry Date': 'expiry_date',
  'Payment Status': 'payment_status',
  'Plan': 'plan',
  'Service': 'service',
  'Currency': 'currency',
  'Paid to': 'paid_to',
  'Notes': 'notes',
  'Instance Number': 'instance_no',
  'Price': 'price',
  'Proxy Set': 'proxy_set',
  'Proxy Count': 'proxy_count',
  'Account count': 'accounts_count',
  'IP Address': 'ip_address',
  "Middleman's Share": 'middleman_share',
  'Amount Paid': 'amount_paid',
  'User Address': 'user_address',
  // '_missing': null,
};
const normalizeDate = (dateStr) => {
  if (!dateStr) return null;

  const trimmed = dateStr.trim();

  // Try parsing with moment explicitly using known formats
  const parsed = moment(trimmed, ['YYYY-MM-DD', 'DD-MM-YYYY', 'MM/DD/YYYY'], true);

  return parsed.isValid() ? parsed.format('YYYY-MM-DD') : null;
};

// const mapToDbSchema = (row) => {
//   const dbRow = {};
//   for (const key in row) {
//     if (columnMap[key]) {
//       // Human-friendly name found in columnMap
//       dbRow[columnMap[key]] = row[key] || null;
//     } else if (Object.values(columnMap).includes(key)) {
//       // Already a valid DB field name
//       dbRow[key] = row[key] || null;
//     } else {
//       console.warn(`⚠️ Unrecognized column: "${key}"`);
//     }
//   }
//   return dbRow;
// };

const mapToDbSchema = (row) => {
  const dbRow = {};
  for (const key in row) {
    const dbKey = columnMap[key] || (Object.values(columnMap).includes(key) ? key : null);
    if (dbKey) {
      let val = row[key] || null;

      // Normalize date fields
      if (['start_date', 'expiry_date'].includes(dbKey) && val) {
        val = normalizeDate(val);
      }

      dbRow[dbKey] = val;
    } else {
      console.warn(`⚠️ Unrecognized column: "${key}"`);
    }
  }
  return dbRow;
};

exports.importClients = async (req, res) => {
  try {
    console.log("📥 Import route hit");
    const clients = req.body.clients;
    console.log("📦 Clients received:", Array.isArray(clients) ? clients.length : 'Not an array');
    if (clients && clients.length > 0) {
      console.log("🔑 First client keys:", Object.keys(clients[0]));
    }
    const insertClient = (client) => {
      return new Promise((resolve, reject) => {
        db.query('INSERT INTO clients SET ?', client, (err, results) => {
          if (err) {
            console.error('🚨 SQL Insert Error:', err.sqlMessage || err.message || err);
            reject(err);
          }
          // else resolve(results);
          resolve(results.insertId);
        });
      });
    };

    const updateLogicalId = (id) => {
      return new Promise((resolve, reject) => {
        db.query('UPDATE clients SET logical_client_id = ? WHERE id = ?', [id, id], (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    };

    // for (const rawClient of clients) {
    //   const client = mapToDbSchema(rawClient);
    //   console.log("🛠️ Mapped row:", client);
    //   const clientId = await insertClient(client);
    //   console.log('📝 Final client before insert:', client);

    //   await updateLogicalId(clientId);
    // }
    const chunkSize = 500; // Adjust as needed
    for (let i = 0; i < clients.length; i += chunkSize) {
      const chunk = clients.slice(i, i + chunkSize).map(mapToDbSchema);

      const insertPromises = chunk.map(client => insertClient(client));
      const insertIds = await Promise.all(insertPromises);

      const logicalUpdatePromises = insertIds.map(id => updateLogicalId(id));
      await Promise.all(logicalUpdatePromises);
    }


    // for (const rawClient of clients) {
    //   const client = mapToDbSchema(rawClient);
    //   console.log("🛠️ Mapped row:", client);
    //   await insertClient(client);
    // }


    res.status(200).json({ message: 'Clients imported successfully' });
  } catch (err) {
    console.error('❌ Import Error:', err);
    res.status(500).json({ error: err.sqlMessage || err.message || 'Import failed' });
  }
};

exports.addClient = async (req, res) => {
  try {
    const client = req.body;

    // Check if client_name exists in DB and NOT adding a new client
    const isExistingClient = client.logical_client_id;

    // Calculate amount due
    const amountPaid = parseFloat(client.amount_paid || 0);
    const price = parseFloat(client.price || 0);
    const amountDue = price - amountPaid;

    let paymentStatus = 'unpaid';
    if (amountDue === 0) paymentStatus = 'paid';
    else if (amountDue < price) paymentStatus = 'partially paid';

    const newClient = {
      ...client,
      amount_paid: amountPaid,
      amount_due: amountDue,
      payment_status: paymentStatus,
    };

    const fields = Object.keys(newClient).join(", ");
    const placeholders = Object.keys(newClient).map(() => "?").join(", ");
    const values = Object.values(newClient);

    const insertSql = `INSERT INTO clients (${fields}) VALUES (${placeholders})`;
    const [result] = await db.promise().query(insertSql, values);

    const newId = result.insertId;

    if (isExistingClient) {
      // Set logical ID same as existing logical_client_id
      await db.promise().query(`UPDATE clients SET logical_client_id = ? WHERE id = ?`, [client.logical_client_id, newId]);
    } else {
      // New client: logical_id = own ID
      await db.promise().query(`UPDATE clients SET logical_client_id = ? WHERE id = ?`, [newId, newId]);
    }

    if (client.middleman_name) {
      updateMiddlemanServiceFlags(client.middleman_name);
    }

    res.status(201).json({ message: 'Client added', id: newId });
  } catch (err) {
    console.error("Add client error:", err);
    res.status(500).json({ error: 'Insert failed', details: err });
  }
};


exports.getClientById = (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM clients WHERE id = ?', [id], (err, results) => {
    if (err || results.length === 0) return res.status(404).json({ error: 'Client not found' });
    res.json(results[0]);
  });
};



exports.bulkUpdateClients = async (req, res) => {
  const { clientIds, updates } = req.body;

  if (!clientIds?.length || !Object.keys(updates).length) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  const setClause = Object.keys(updates).map(field => `${field} = ?`).join(', ');
  const values = [...Object.values(updates), ...clientIds];
  const sql = `UPDATE clients SET ${setClause} WHERE id IN (${clientIds.map(() => '?').join(', ')})`;

  try {
    await db.promise().query(sql, values);
    res.json({ message: 'Clients updated successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Bulk update failed' });
  }
};

exports.getExpiringClients = async (req, res) => {
  const user = req.user;
  const { page = 1, limit = 50, expiryRange = 'next_3_days' } = req.query;
  const offset = (page - 1) * limit;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let sql = `
    SELECT c.*
    FROM clients c
    WHERE c.is_cancelled = 0 
      AND c.is_deleted = 0
      AND c.expiry_date IS NOT NULL
      AND c.id NOT IN (
    SELECT renewed_from_id FROM clients
    WHERE renewed_from_id IS NOT NULL
      AND is_cancelled = 0
      AND is_deleted = 0
  )
  `;
  const params = [];

  // ✅ Expiry Date Range Logic
  if (expiryRange === 'next_3_days') {
    const next3 = new Date(today);
    next3.setDate(today.getDate() + 3);
    sql += ` AND c.expiry_date >= ? AND c.expiry_date <= ?`;
    params.push(today, next3);
  } else if (expiryRange === 'next_7_days') {
    const next7 = new Date(today);
    next7.setDate(today.getDate() + 7);
    sql += ` AND c.expiry_date >= ? AND c.expiry_date <= ?`;
    params.push(today, next7);
  } else if (expiryRange === 'none') {
    const next3 = new Date(today);
    next3.setDate(today.getDate() + 3);
    sql += ` AND c.expiry_date <= ?`;
    params.push(next3);
  }

  // ✅ Role-Based Filtering
  if (user.role === 'admin') {
    sql += ` AND c.logical_client_id NOT IN (
      SELECT logical_client_id FROM client_admin_exclusions WHERE admin_id = ?
    )`;
    params.push(user.id);
  } else if (user.role === 'middleman') {
    sql += ` AND c.middleman_name = (SELECT username FROM users WHERE id = ?)`;
    params.push(user.id);
  }

  // ✅ Count query
  const countSql = `SELECT COUNT(*) AS total FROM (${sql}) AS count_alias`;

  try {
    const [countResult] = await db.promise().query(countSql, params);
    const total = countResult[0]?.total || 0;

    sql += ` LIMIT ? OFFSET ?`;
    params.push(Number(limit), Number(offset));

    const [rows] = await db.promise().query(sql, params);

    const now = new Date();
    now.setHours(0, 0, 0, 0);

    // ✅ Status logic
    const withStatus = rows.map(row => {
      const expiryDate = new Date(row.expiry_date);
      expiryDate.setHours(0, 0, 0, 0);

      let status = '';
      if (expiryDate < now) status = 'Expired';
      else if (expiryDate.getTime() === now.getTime()) status = 'Expiring Today';
      else status = 'Expiring Soon';

      return { ...row, status };
    });

    res.json({
      clients: withStatus,
      total,
      page: Number(page),
      limit: Number(limit)
    });
  } catch (err) {
    console.error('Failed to fetch expiring clients:', err);
    res.status(500).json({ error: 'Failed to fetch expiring clients' });
  }
};



// exports.bulkRenewClients = async (req, res) => {
//   const { clientIds, startDate, expiryDate } = req.body;
//   if (!Array.isArray(clientIds) || clientIds.length === 0) {
//     return res.status(400).json({ error: 'No clients selected for renewal.' });
//   }

//   try {
//     for (const clientId of clientIds) {
//       const [rows] = await db.promise().query("SELECT * FROM clients WHERE id = ?", [clientId]);
//       if (rows.length === 0) continue;

//       const client = rows[0];
//       // clone the row, set new dates
//       const insertData = {
//         ...client,
//         start_date: startDate,
//         expiry_date: expiryDate
//       };
//       delete insertData.id;

//       const fields = Object.keys(insertData).join(", ");
//       const placeholders = Object.keys(insertData).map(() => '?').join(', ');
//       const values = Object.values(insertData);

//       await db.promise().query(`INSERT INTO clients (${fields}) VALUES (${placeholders})`, values);
//     }

//     res.json({ message: 'Clients renewed successfully' });
//   } catch (err) {
//     console.error('Bulk renew failed:', err);
//     res.status(500).json({ error: 'Failed to renew clients' });
//   }
// };

// exports.getCancelledClients = async (req, res) => {
//   const { role, username } = req.user;
//   const { from, to, page = 1, limit = 50 } = req.query;
//   const offset = (page - 1) * limit;

//   let conditions = 'is_cancelled = 1';
//   let params = [];

//   if (from && to) {
//     conditions += ' AND expiry_date BETWEEN ? AND ?';
//     params.push(from, to);
//   }

//   if (role === 'middleman') {
//     conditions += ' AND middleman_name = ?';
//     params.push(username);
//   } else if (role === 'admin') {
//     conditions += ` AND logical_client_id NOT IN (SELECT logical_client_id FROM excluded_clients WHERE admin_username = ?)`;
//     params.push(username);
//   }

//   const dataSql = `SELECT id, client_name, service, middleman_name, price, currency, expiry_date, cancelled_on FROM clients WHERE ${conditions} LIMIT ? OFFSET ?`;
//   const countSql = `SELECT COUNT(*) as total FROM clients WHERE ${conditions}`;

//   try {
//     const [dataResults] = await db.promise().query(dataSql, [...params, parseInt(limit), parseInt(offset)]);
//     const [countResults] = await db.promise().query(countSql, params);

//     res.json({
//       clients: dataResults,
//       total: countResults[0].total
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: 'Failed to fetch cancelled clients' });
//   }
// };

exports.bulkRenewClients = async (req, res) => {
  const { clientIds, startDate, expiryDate } = req.body;

  if (!Array.isArray(clientIds) || clientIds.length === 0) {
    return res.status(400).json({ error: 'No clients selected for renewal.' });
  }

  try {
    for (const clientId of clientIds) {
      const [rows] = await db.promise().query("SELECT * FROM clients WHERE id = ?", [clientId]);
      if (rows.length === 0) continue;

      const client = rows[0];

      // clone the row, set new dates and renewed_from_id
      const insertData = {
        ...client,
        start_date: startDate,
        expiry_date: expiryDate,
        renewed_from_id: clientId, // ✅ NEW FIELD
        created_at: new Date()     // optional if you track creation
      };

      delete insertData.id;         // remove auto-increment ID
      delete insertData.updated_at; // optional: remove if exists to reset timestamps

      const fields = Object.keys(insertData).join(", ");
      const placeholders = Object.keys(insertData).map(() => '?').join(', ');
      const values = Object.values(insertData);

      await db.promise().query(`INSERT INTO clients (${fields}) VALUES (${placeholders})`, values);
    }

    res.json({ message: 'Clients renewed successfully' });
  } catch (err) {
    console.error('Bulk renew failed:', err);
    res.status(500).json({ error: 'Failed to renew clients' });
  }
};


exports.getCancelledClients = async (req, res) => {
  const user = req.user;
  const { from, to, dateFilter = 'last30', service, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;

  let conditions = 'is_cancelled = 1 AND is_deleted = 0';
  let params = [];

  let dateFrom = from;
  let dateTo = to;

  // If from and to are not provided, fallback to dateFilter range
  if (!from || !to) {
    const range = getDateRangeForFilter(dateFilter);
    if (range.start && range.end) {
      dateFrom = range.start;
      dateTo = range.end;
    }
  }

  if (dateFrom && dateTo) {
    conditions += ' AND expiry_date BETWEEN ? AND ?';
    params.push(dateFrom, dateTo);
  }

  if (user.role === 'middleman') {
    conditions += ' AND middleman_name = (SELECT username FROM users WHERE id = ?)';
    params.push(user.id);
  } else if (user.role === 'admin') {
    conditions += ` AND logical_client_id NOT IN (SELECT logical_client_id FROM client_admin_exclusions WHERE admin_id = ?)`;
    params.push(user.id);
  }

  if (service && service !== 'all') {
    conditions += ' AND service = ?';
    params.push(service);
  }

  const dataSql = `SELECT * 
                   FROM clients WHERE ${conditions} 
                   LIMIT ? OFFSET ?`;
  const countSql = `SELECT COUNT(*) as total FROM clients WHERE ${conditions}`;

  try {
    const [dataResults] = await db.promise().query(dataSql, [...params, parseInt(limit), parseInt(offset)]);
    const [countResults] = await db.promise().query(countSql, params);

    res.json({
      clients: dataResults,
      total: countResults[0].total
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch cancelled clients' });
  }
};


exports.bulkRestoreClients = async (req, res) => {
  const { clientIds } = req.body;

  if (!clientIds || clientIds.length === 0) {
    return res.status(400).json({ error: "No clients provided" });
  }

  try {
    const placeholders = clientIds.map(() => '?').join(',');
    const sql = `UPDATE clients SET is_cancelled = 0 WHERE id IN (${placeholders})`;
    await db.promise().query(sql, clientIds);

    res.json({ message: "Clients restored successfully" });
  } catch (err) {
    console.error("Error restoring clients:", err);
    res.status(500).json({ error: "Failed to restore clients" });
  }
};


exports.bulkDeleteClients = async (req, res) => {
  const { clientIds } = req.body;

  if (!clientIds || clientIds.length === 0) {
    return res.status(400).json({ error: "No clients provided" });
  }

  try {
    const placeholders = clientIds.map(() => '?').join(',');
    const sql = `UPDATE clients SET is_deleted = 1, deleted_on = CURDATE() WHERE id IN (${placeholders})`;
    await db.promise().query(sql, clientIds);

    res.json({ message: "Clients deleted successfully" });
  } catch (err) {
    console.error("Error deleting clients:", err);
    res.status(500).json({ error: "Failed to delete clients" });
  }
};


exports.getDeletedClients = (req, res) => {
  const user = req.user;
  const { dateFilter, from, to, service, page = 1, limit = 50 } = req.query;

  let sql = `SELECT * FROM clients WHERE is_deleted = 1`;
  const params = [];

  // Apply filter by expiry date
  let dateFrom = from, dateTo = to;
  if (!from || !to) {
    const range = getDateRangeForFilter(dateFilter);
    if (range.start && range.end) {
      dateFrom = range.start;
      dateTo = range.end;
    }
  }

  sql += ` AND DATE(expiry_date) BETWEEN ? AND ?`;
  params.push(dateFrom, dateTo);

  if (user.role === 'admin') {
    sql += ` AND logical_client_id NOT IN (SELECT logical_client_id FROM client_admin_exclusions WHERE admin_id = ?)`;
    params.push(user.id);
  } else if (user.role === 'middleman') {
    sql += ` AND middleman_name = (SELECT username FROM users WHERE id = ?)`;
    params.push(user.id);
  }

  if (service && service !== 'all') {
    sql += ' AND service = ?';
    params.push(service);
  }

  const offset = (page - 1) * limit;
  const countSql = `SELECT COUNT(*) AS total FROM (${sql}) AS count_query`;

  db.query(countSql, params, (countErr, countRes) => {
    if (countErr) return res.status(500).json({ error: 'Count failed' });

    const paginatedSql = `${sql} LIMIT ? OFFSET ?`;
    db.query(paginatedSql, [...params, parseInt(limit), parseInt(offset)], (err, rows) => {
      if (err) return res.status(500).json({ error: 'Query failed' });

      const response = {
        clients: user.role === 'middleman'
          ? rows.map(c => {
            delete c.middleman_name;
            return c;
          })
          : rows,
        total: countRes[0]?.total || 0,
        page: Number(page),
        limit: Number(limit),
      };
      res.json(response);
    });
  });
};


exports.bulkDeleteClientsPermanently = (req, res) => {
  const { clientIds } = req.body;
  if (!clientIds || !Array.isArray(clientIds)) {
    return res.status(400).json({ error: 'Invalid clientIds' });
  }

  const placeholders = clientIds.map(() => '?').join(',');
  const sql = `DELETE FROM clients WHERE id IN (${placeholders})`;

  db.query(sql, clientIds, (err, result) => {
    if (err) {
      console.error('Error deleting clients:', err);
      return res.status(500).json({ error: 'Failed to delete clients' });
    }
    res.json({ success: true, deletedCount: result.affectedRows });
  });
};




// exports.getClientReport = async (req, res) => {
//   const { logicalClientId } = req.params;
//   const { year, from, to } = req.query;

//   try {
//     let whereClause = 'WHERE logical_client_id = ?';
//     const params = [logicalClientId];

//     if (year && year !== 'custom') {
//       whereClause += ' AND YEAR(start_date) = ?';
//       params.push(year);
//     } else if (from && to) {
//       whereClause += ' AND start_date BETWEEN ? AND ?';
//       params.push(from, to);
//     }

//     const getLatestMiddleman = `
//       SELECT middleman_name FROM clients
//       WHERE logical_client_id = ?
//       ORDER BY id DESC LIMIT 1
//     `;
//     const [[{ middleman_name } = {}]] = await db.promise().query(getLatestMiddleman, [logicalClientId]);

//     const [services] = await db.promise().query(`
//       SELECT service, COUNT(*) AS active_count
//       FROM clients
//       ${whereClause} AND is_cancelled = 0 AND is_deleted = 0
//       GROUP BY service
//     `, params);

//     const [revenue] = await db.promise().query(`
//       SELECT price, currency FROM clients
//       ${whereClause} AND is_cancelled = 0 AND is_deleted = 0
//     `, params);

//     const [pending] = await db.promise().query(`
//       SELECT amount_due, currency FROM clients
//       ${whereClause} AND is_cancelled = 0 AND is_deleted = 0
//     `, params);

//     const [graph] = await db.promise().query(`
//       SELECT MONTH(start_date) AS month, SUM(price) AS total, currency
//       FROM clients
//       ${whereClause} AND is_cancelled = 0 AND is_deleted = 0
//       GROUP BY MONTH(start_date), currency
//     `, params);

//     const [table] = await db.promise().query(`
//       SELECT created_at, service, plan, accounts_count, proxy_count, price, currency,
//         start_date, expiry_date, middleman_share, payment_status, amount_paid, paid_to, notes
//       FROM clients
//       ${whereClause}
//     `, params);

//     const convertToUSD = async (amount, currency) => {
//       if (currency === 'USD') return amount;
//       const rates = { INR: 0.012, EUR: 1.1 };
//       return (amount || 0) * (rates[currency] || 1);
//     };

//     let totalRevenueUSD = 0;
//     for (const row of revenue) totalRevenueUSD += await convertToUSD(row.price, row.currency);

//     let totalDueUSD = 0;
//     for (const row of pending) totalDueUSD += await convertToUSD(row.amount_due, row.currency);

//     const graphData = {};
//     for (const row of graph) {
//       const converted = await convertToUSD(row.total, row.currency);
//       graphData[row.month] = (graphData[row.month] || 0) + converted;
//     }

//     res.json({
//       serviceCounts: services,
//       totalRevenueUSD,
//       totalDueUSD,
//       graphData,
//       table,
//       middlemanName: middleman_name
//     });
//   } catch (err) {
//     console.error("Client report error:", err);
//     res.status(500).json({ error: "Failed to generate client report" });
//   }
// };

const getExchangeRates = async () => {
  try {
    const response = await axios.get('https://open.er-api.com/v6/latest/USD');
    return response.data?.rates || {};
  } catch (err) {
    console.error('❌ Failed to fetch exchange rates:', err.message);
    return {}; // fallback to avoid crash
  }
};

exports.getClientReport = async (req, res) => {
  // const { logicalClientId } = req.params;
  const { id: logicalClientId } = req.params;

  const { year, from, to } = req.query;

  if (!logicalClientId) {
    console.error("❌ Missing logicalClientId in request params");
    return res.status(400).json({ error: "Missing client ID" });
  }

  let startDate, endDate;

  if (year && year !== 'custom') {
    startDate = `${year}-01-01`;
    endDate = `${year}-12-31`;
  } else if (from && to) {
    startDate = from;
    endDate = to;
  } else {
    const now = new Date();
    startDate = `${now.getFullYear()}-01-01`;
    endDate = `${now.getFullYear()}-12-31`;
  }

  try {
    // Fetch basic client + middleman name
    const exchangeRates = await getExchangeRates();
    const [infoRows] = await db.promise().query(`
      SELECT client_name, middleman_name 
      FROM clients 
      WHERE logical_client_id = ? 
      ORDER BY id DESC LIMIT 1
    `, [logicalClientId]);

    const { client_name, middleman_name } = infoRows[0] || {};

    // Fetch all services count
    const [services] = await db.promise().query(`
      SELECT service, COUNT(*) AS count 
      FROM clients 
      WHERE logical_client_id = ? AND is_cancelled = 0 AND is_deleted = 0
      GROUP BY service
    `, [logicalClientId]);

    const serviceMap = services.map(s => ({
      name: s.service.charAt(0).toUpperCase() + s.service.slice(1),
      count: s.count
    }));

    // Fetch total revenue (in USD)
    const [revenueRows] = await db.promise().query(`
      SELECT price, currency 
      FROM clients 
      WHERE logical_client_id = ? 
      AND start_date BETWEEN ? AND ? 
      
    `, [logicalClientId, startDate, endDate]);

    let totalRevenueUSD = 0;
    for (const row of revenueRows) {
      let amt = parseFloat(row.price || 0);
      // if (row.currency && row.currency !== 'USD') {
      //   // Dummy conversion, replace with your logic
      //   if (row.currency === 'INR') amt /= 83;
      //   else if (row.currency === 'EUR') amt *= 1.1;
      // }
      if (row.currency && row.currency !== 'USD') {
        const rate = exchangeRates[row.currency];
        if (rate) amt /= rate;
      }
      totalRevenueUSD += amt;
    }

    //Fetch total paid (in USD)
    const [PaidRows] = await db.promise().query(`
      SELECT amount_paid, currency 
      FROM clients 
      WHERE logical_client_id = ? 
      AND start_date BETWEEN ? AND ? 
      
    `, [logicalClientId, startDate, endDate]);

    let totalPaidUSD = 0;
    for (const row of PaidRows) {
      let amt = parseFloat(row.amount_paid || 0);
      // if (row.currency && row.currency !== 'USD') {
      //   // Dummy conversion, replace with your logic
      //   if (row.currency === 'INR') amt /= 83;
      //   else if (row.currency === 'EUR') amt *= 1.1;
      // }
      if (row.currency && row.currency !== 'USD') {
        const rate = exchangeRates[row.currency];
        if (rate) amt /= rate;
      }
      totalPaidUSD += amt;
    }
    // Fetch total due (in USD)
    const [dueRows] = await db.promise().query(`
      SELECT amount_due, currency 
      FROM clients 
      WHERE logical_client_id = ? 
      AND start_date BETWEEN ? AND ? 

    `, [logicalClientId, startDate, endDate]);

    let totalDueUSD = 0;
    for (const row of dueRows) {
      let amt = parseFloat(row.amount_due || 0);
      // if (row.currency && row.currency !== 'USD') {
      //   if (row.currency === 'INR') amt /= 83;
      //   else if (row.currency === 'EUR') amt *= 1.1;
      // }
      if (row.currency && row.currency !== 'USD') {
        const rate = exchangeRates[row.currency];
        if (rate) amt /= rate;
      }
      totalDueUSD += amt;
    }

    // Monthly graph
    // const [graphRows] = await db.promise().query(`
    //   SELECT MONTH(start_date) AS month, SUM(CASE 
    //     WHEN currency = 'USD' THEN price
    //     WHEN currency = 'INR' THEN price * ?
    //     WHEN currency = 'EUR' THEN price * ? 
    //     ELSE price
    //   END) AS total
    //   FROM clients 
    //   WHERE logical_client_id = ? 
    //   AND start_date BETWEEN ? AND ? 
    //   GROUP BY MONTH(start_date)
    // `, [usdRates.INR, usdRates.EUR, logicalClientId, startDate, endDate]);
    const [graphRows] = await db.promise().query(`
      SELECT MONTH(start_date) AS month, price, currency 
      FROM clients 
      WHERE logical_client_id = ? 
      AND start_date BETWEEN ? AND ?
    `, [logicalClientId, startDate, endDate]);

    // const graphData = Array.from({ length: 12 }, (_, i) => {
    //   const match = graphRows.find(r => r.month === i + 1);
    //   return {
    //     month: new Date(0, i).toLocaleString('default', { month: 'short' }),
    //     total: match ? parseFloat(match.total.toFixed(2)) : 0
    //   };
    // });
    const monthTotals = Array(12).fill(0);
    for (const row of graphRows) {
      const monthIndex = row.month - 1;
      let amt = parseFloat(row.price || 0);
      if (row.currency && row.currency !== 'USD') {
        const rate = exchangeRates[row.currency];
        if (rate) amt /= rate;
      }
      monthTotals[monthIndex] += amt;
    }

    const graphData = monthTotals.map((total, i) => ({
      month: new Date(0, i).toLocaleString('default', { month: 'short' }),
      total: parseFloat(total.toFixed(2))
    }));
    // const graphData = Array.from({ length: 12 }, (_, i) => {
    //   const match = graphRows.find(r => r.month === i + 1);
    //   const totalValue = match?.total ? Number(match.total) : 0;
    //   return {
    //     month: new Date(0, i).toLocaleString('default', { month: 'short' }),
    //     total: parseFloat(totalValue.toFixed(2))
    //   };
    // });


    // Sales table data
    const [salesData] = await db.promise().query(`
      SELECT created_at, service, plan, accounts_count, proxy_count, price, currency, 
        start_date, expiry_date, middleman_share, payment_status, amount_paid, paid_to, notes 
      FROM clients 
      WHERE logical_client_id = ? 
      AND start_date BETWEEN ? AND ?
      
    `, [logicalClientId, startDate, endDate]);

    // res.json({
    //   summary: {
    //     clientName: client_name,
    //     middleman: middleman_name,
    //     services: serviceMap,
    //     totalRevenueUSD: totalRevenueUSD.toFixed(2),
    //     totalDueUSD: totalDueUSD.toFixed(2)
    //   },
    //   graphData,
    //   salesData
    // });

    const summary = {
      clientName: client_name,
      middleman: middleman_name,
      services: serviceMap,
      totalRevenueUSD: totalRevenueUSD.toFixed(2),
      totalPaidUSD: totalPaidUSD.toFixed(2),
      totalDueUSD: totalDueUSD.toFixed(2)
    };

    // Make sure all services are included (even with 0)
    // const allServices = ['cerberus', 'vps', 'proxy', 'storage', 'varys'];
    // const serviceCountMap = Object.fromEntries(
    //   services.map(s => [s.service, s.count])
    // );

    // summary.services = allServices.map(service => ({
    //   name: service.charAt(0).toUpperCase() + service.slice(1),
    //   count: serviceCountMap[service] || 0
    // }));

    res.json({ summary, graphData, salesData });

  } catch (err) {
    console.error('📉 Client report error:', err);
    res.status(500).json({ error: 'Failed to generate report' });
  }
};


exports.deleteLogicalClient = async (req, res) => {
  const user = req.user;

  if (user.role !== 'superadmin') {
    return res.status(403).json({ error: 'Unauthorized. Only superadmin can delete clients.' });
  }

  const { logicalClientId } = req.params;

  try {
    await db.promise().query(
      'DELETE FROM clients WHERE logical_client_id = ?',
      [logicalClientId]
    );
    res.status(200).json({ message: 'Client deleted successfully' });
  } catch (err) {
    console.error('Delete logical client error:', err);
    res.status(500).json({ error: 'Failed to delete client' });
  }
};


exports.getDashboardStats = async (req, res) => {
  const { role, id: userId, username } = req.user;

  try {
    // 1. Conditions based on role
    let conditions = 'expiry_date >= CURDATE() AND is_cancelled = 0 AND is_deleted = 0';
    const params = [];

    if (role === 'middleman') {
      conditions += ' AND middleman_name = (SELECT username FROM users WHERE id = ?)';
      params.push(userId);
    } else if (role === 'admin') {
      conditions += ` AND id NOT IN (SELECT logical_client_id FROM client_admin_exclusions WHERE admin_id = ?)`;
      params.push(userId);
    }

    // 2. Active Clients
    const [clients] = await db.promise().query(`SELECT * FROM clients WHERE ${conditions}`, params);
    const totalClients = clients.length;

    // 3. Active Services
    // const totalActiveServices = new Set(clients.map(c => `${c.logical_client_id}-${c.service}`)).size;
    const [activeServicesRows] = await db.promise().query(`
      SELECT DISTINCT service FROM clients 
      WHERE ${conditions}
    `, params);
    const totalActiveServices = activeServicesRows.length;


    // 4. Upcoming Expiries
    const [expiries] = await db.promise().query(
      `SELECT COUNT(*) AS count FROM clients WHERE ${conditions} AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)`,
      params
    );
    const upcomingExpiries = expiries[0].count;

    // 5. Revenue (Convert to USD)
    let revenueUSD = 0;
    const rates = await getExchangeRates();

    const convertToUSD = (amount, currency = 'USD') => {
      currency = currency?.toUpperCase().trim();
      if (!amount || !rates[currency]) {
        console.warn(`Unknown or missing currency: ${currency}`);
        return 0;
      }
      return amount / rates[currency];
    };

    for (const client of clients) {
      const startDate = new Date(client.start_date);
      const now = new Date();

      const sameMonth = startDate.getMonth() === now.getMonth();
      const sameYear = startDate.getFullYear() === now.getFullYear();

      if (!sameMonth || !sameYear) continue;  // Skip clients not from current month
      // const {
      //   price = 0,
      //   currency = 'USD',
      //   middleman_share = 0,
      //   jitesh_share = 0,
      //   queen_share = 0,
      //   atlas_jitesh = 0,
      //   middleman_name = ''
      // } = client;
      const price = Number(client.price || 0);
      const currency = (client.currency || 'USD').toUpperCase().trim();
      const middleman_share = Number(client.middleman_share || 0);
      const jitesh_share = Number(client.jitesh_share || 0);
      const queen_share = Number(client.queen_share || 0);
      const atlas_jitesh = Number(client.atlas_jitesh || 0);
      const middleman_name = client.middleman_name || '';


      if (role === 'superadmin') {
        const cost = middleman_share + jitesh_share + queen_share + atlas_jitesh;
        revenueUSD += convertToUSD(price - cost, currency);
      } else if (role === 'middleman') {
        revenueUSD += convertToUSD(middleman_share, currency);
      } else if (role === 'admin') {
        let amt = 0;
        const isJitesh = username === 'jitesh';
        const isQueen = username === 'lord_queen';

        if (middleman_name === username) amt += middleman_share;
        if (isJitesh) amt += jitesh_share + atlas_jitesh;
        else if (isQueen) amt += queen_share;

        revenueUSD += convertToUSD(amt, currency);
      }
    }

    // 6. Recently Added Clients
    const [recentClients] = await db.promise().query(
      `SELECT client_name, service, plan, middleman_name, start_date, expiry_date
       FROM clients
       WHERE ${conditions}
       ORDER BY id DESC
       LIMIT 10`,
      params
    );

    // 7. Final Response
    res.json({
      totalClients,
      totalActiveServices,
      upcomingExpiries,
      revenueUSD: revenueUSD.toFixed(2),
      recentClients
    });

  } catch (error) {
    console.error('❌ Dashboard stats error:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard stats' });
  }
};