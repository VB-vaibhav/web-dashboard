// const db = require('../config/db');

// // 🔹 Get paginated + filterable custom notifications
// exports.getCustomNotifications = async (req, res) => {
//   const { role } = req.user;
//   let { page = 1, limit = 20, filter, from, to } = req.query;

//   page = parseInt(page);
//   limit = parseInt(limit);
//   const offset = (page - 1) * limit;

//   let conditions = 'WHERE 1';
//   const params = [];

//   // 📅 Filter logic
//   if (filter && !from && !to) {
//     const now = new Date();
//     let fromDate;

//     switch (filter) {
//       case 'today':
//         fromDate = new Date();
//         break;
//       case 'this_week':
//         fromDate = new Date(now.setDate(now.getDate() - 7));
//         break;
//       case 'this_month':
//         fromDate = new Date(now.setDate(now.getDate() - 30));
//         break;
//       case 'this_quarter':
//         fromDate = new Date(now.setDate(now.getDate() - 90));
//         break;
//       case 'this_year':
//         fromDate = new Date(now.setFullYear(now.getFullYear() - 1));
//         break;
//     }

//     if (fromDate) {
//       conditions += ` AND date_sent >= ?`;
//       params.push(fromDate.toISOString().split('T')[0]);
//     }
//   } else if (from && to) {
//     conditions += ` AND date_sent BETWEEN ? AND ?`;
//     params.push(from, to);
//   }

//   const sql = `
//     SELECT *
//     FROM custom_notifications
//     ${conditions}
//     ORDER BY date_sent DESC, time_sent DESC
//     LIMIT ? OFFSET ?
//   `;

//   const countSql = `
//     SELECT COUNT(*) as count
//     FROM custom_notifications
//     ${conditions}
//   `;

//   try {
//     const [rows] = await db.promise().query(sql, [...params, limit, offset]);
//     const [count] = await db.promise().query(countSql, params);

//     res.json({
//       data: rows,
//       total: count[0].count,
//       currentPage: page,
//       totalPages: Math.ceil(count[0].count / limit)
//     });
//   } catch (err) {
//     console.error("❌ Failed to fetch custom notifications:", err);
//     res.status(500).json({ error: 'Server Error' });
//   }
// };
