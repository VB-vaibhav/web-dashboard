require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');


const clientRoutes = require('./routes/clientRoutes');

const adminRoutes = require('./routes/adminRoutes');
const authRoutes = require('./routes/authRoutes');
const app = express();

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

app.use((req, res, next) => {
  const userAgent = req.get('User-Agent') || '';
  const blacklist = ['PostmanRuntime', 'curl', 'Insomnia'];


  if (blacklist.some(agent => userAgent.includes(agent))) {
    return res.status(403).send("Direct API access from API tools is blocked.");
  }
  next();
});
app.use(cors({ origin: ['https://portal.theearthace.com', 'http://localhost:5173'], credentials: true }));
app.use(cookieParser());
app.use(express.json());

// ✅ Serve uploaded avatars statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/custom-notifications', require('./routes/customNotificationRoutes'));

// Optional: turn on cron via ENV
// if (process.env.ENABLE_CRON === '1') {
//   require('./workers/notificationWorker');
// }


if (process.env.ENABLE_CRON === '1') {
  const cron = require('node-cron');
  const { runOnce } = require('./workers/customNotificationWorker');

  // run every minute
  cron.schedule('* * * * *', async () => {
    try {
      await runOnce();
    } catch (e) {
      console.error('Custom notification cron failed:', e);
    }
  });
}


// app.listen(process.env.PORT || 5000, () => {
//   console.log("Server running on port", process.env.PORT);
// });


// const port = process.env.PORT || 5000;
// app.listen(port, '0.0.0.0', () => {
//   console.log("Server running on port", port);
// });
const cron = require('node-cron');
const { generateExpiryNotifications } = require('./controllers/notificationController');

const http = require('http');

const port = process.env.PORT || 5000;

// Create HTTP server with extended timeout
const server = http.createServer(app);

// ⏱ Increase timeout to 5 minutes (default is only 2 minutes)
server.timeout = 5 * 60 * 1000; // 5 minutes in milliseconds

server.listen(port, '0.0.0.0', () => {
  console.log("✅ Server running on port", port);
});


// Run every day at 12:05 AM
cron.schedule('5 0 * * *', async () => {
  try {
    console.log("🕐 Running daily notification job...");
    await generateExpiryNotifications();
  } catch (err) {
    console.error("❌ Failed to run notification cron:", err);
  }
});



// require('dotenv').config();
// const express = require('express');
// const cors = require('cors');
// const cookieParser = require('cookie-parser');
// const path = require('path');

// const app = express(); // ✅ Must be before use()

// // ✅ CORS Setup with OPTIONS support
// const allowedOrigins = ['https://portal.theearthace.com', 'http://localhost:5173'];

// const corsOptions = {
//   origin: allowedOrigins,
//   credentials: true,
//   methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
//   allowedHeaders: ['Content-Type', 'Authorization'],
// };


// // ✅ Body Parsers with Upload Limit
// app.use(express.json({ limit: '20mb' }));
// app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// // ✅ Block Postman/curl tools
// app.use((req, res, next) => {
//   const userAgent = req.get('User-Agent') || '';
//   const blacklist = ['PostmanRuntime', 'Insomnia'];
//   if (blacklist.some(agent => userAgent.includes(agent))) {
//     return res.status(403).send("Direct API access from API tools is blocked.");
//   }
//   next();
// });

// app.use(cors(corsOptions));
// app.options('*', cors(corsOptions)); // ✅ Explicitly handle preflight

// app.use(cookieParser());

// // ✅ Serve uploaded avatars
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// // ✅ Routes
// const adminRoutes = require('./routes/adminRoutes');
// const clientRoutes = require('./routes/clientRoutes');
// const authRoutes = require('./routes/authRoutes');

// app.use('/api/auth', authRoutes);
// app.use('/api/admin', adminRoutes);
// app.use('/api/clients', clientRoutes);

// // ✅ Start server
// const port = process.env.PORT || 5000;
// app.listen(port, '0.0.0.0', () => {
//   console.log("Server running on port", port);
// });
// console.log('ENV:', process.env.NODE_ENV, 'PORT:', process.env.PORT);

