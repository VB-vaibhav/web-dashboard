const router = require('express').Router();
const notificationController = require('../controllers/notificationController');
const { verifyToken } = require('../middleware/authMiddleware');

router.post('/generate', verifyToken, async (req, res) => {
    try {
        await notificationController.generateExpiryNotifications();
        res.send({ message: "Notifications generated." });
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("Generation failed");
    }
});
router.get('/', verifyToken, notificationController.getNotifications);
router.patch('/ignore/:id', verifyToken, notificationController.ignoreNotification);
router.get('/count', verifyToken, notificationController.getNotificationCount);
module.exports = router;
