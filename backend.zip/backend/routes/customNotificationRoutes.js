// const express = require('express');
// const router = express.Router();
// const db = require('../config/db');
// const { verifyToken, requireRole } = require('../middleware/authMiddleware');
// const { getDateRangeForFilter } = require('../utils/dateUtils'); // Make sure this exists

// // GET /api/custom-notifications
// router.get('/', verifyToken, requireRole('superadmin'), async (req, res) => {
//   const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

//   const parsedPage = parseInt(page);
//   const parsedLimit = parseInt(limit);
//   const offset = (parsedPage - 1) * parsedLimit;

//   let dateFrom = from;
//   let dateTo = to;

//   // ⏳ Use utility if custom dates not provided
//   if (!from || !to) {
//     const range = getDateRangeForFilter(dateFilter);
//     if (range.start && range.end) {
//       dateFrom = range.start;
//       dateTo = range.end;
//     }
//   }

//   try {
//     // COUNT total matching rows
//     const countQuery = `
//       SELECT COUNT(*) AS total 
//       FROM custom_notifications 
//       WHERE date_sent BETWEEN ? AND ?
//     `;
//     const [countRows] = await db.promise().query(countQuery, [dateFrom, dateTo]);
//     const total = countRows[0]?.total || 0;

//     // FETCH actual rows (paginated)
//     const dataQuery = `
//       SELECT * 
//       FROM custom_notifications 
//       WHERE date_sent BETWEEN ? AND ?
//       ORDER BY date_sent DESC, time_sent DESC
//       LIMIT ? OFFSET ?
//     `;
//     const [rows] = await db.promise().query(dataQuery, [dateFrom, dateTo, parsedLimit, offset]);

//     res.json({
//       notifications: rows,
//       total,
//       page: parsedPage,
//       limit: parsedLimit
//     });
//   } catch (err) {
//     console.error("❌ Error fetching custom notifications:", err);
//     res.status(500).json({ error: 'Failed to fetch notifications' });
//   }
// });

// module.exports = router;





const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifyToken } = require('../middleware/authMiddleware');
const { getDateRangeForFilter } = require('../utils/dateUtils'); // you already use this
const sanitizeHtml = require('sanitize-html');

const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc');
const tz = require('dayjs/plugin/timezone');
dayjs.extend(utc); dayjs.extend(tz);

const appTz = process.env.APP_TZ || 'Asia/Kolkata';

/* -------- helpers -------- */

// lightweight role gate (no change to your middleware files)
const allowRoles = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
  next();
};

const cleanHtml = (html = '') =>
  sanitizeHtml(html, {
    allowedTags: sanitizeHtml.defaults.allowedTags.concat([
      'img','h1','h2','h3','u','span','ol','ul','li','table','thead','tbody','tr','td','th'
    ]),
    allowedAttributes: {
      '*': ['style','class'],
      a: ['href','name','target','rel'],
      img: ['src','alt'],
      ol: ['type','start']
    },
    allowedSchemes: ['http','https','data','mailto','tel'],
    allowedSchemesByTag: { img: ['http','https','data'] }
  });


/* -------- recipients for react-select -------- */
// GET /api/custom-notifications/recipients?type=all|admin|middleman
router.get('/recipients', verifyToken, allowRoles('admin', 'superadmin'), async (req, res) => {
  try {
    const type = (req.query.type || 'all').toLowerCase();
    let sql = "SELECT id AS value, username AS label FROM users";
    if (type === 'admin') sql += " WHERE role='admin'";
    if (type === 'middleman') sql += " WHERE role='middleman'";
    sql += " ORDER BY username";
    const [rows] = await db.promise().query(sql);
    res.json(rows);
  } catch (err) {
    console.error('recipients error:', err);
    res.status(500).json({ error: 'Failed to fetch recipients' });
  }
});

/* -------- send now -------- */
// POST /api/custom-notifications
// Body: { title, messageHtml, recipientType, recipientLabels?[], schedulerNotes? }
router.post('/', verifyToken, allowRoles('admin', 'superadmin'), async (req, res) => {
  try {
    const { id: userId } = req.user;
    const { title, messageHtml, recipientType, recipientLabels } = req.body;

    if (!title || !title.trim()) return res.status(400).json({ error: 'Title is required' });
    if (!recipientType) return res.status(400).json({ error: 'Recipient type is required' });

    const safeHtml = cleanHtml(messageHtml);
    const sentTo =
      Array.isArray(recipientLabels) && recipientLabels.length
        ? recipientLabels.join(', ')
        : (recipientType === 'all' ? 'All' : '(none)');

    const now = dayjs().tz(appTz);
    const datePart = now.format('YYYY-MM-DD');
    const timePart = now.format('HH:mm:ss');

    await db.promise().query(
      `INSERT INTO custom_notifications
       (title, message_html, recipient_type, sent_to, user_id, date_sent, time_sent, send_status)
       VALUES (?, ?, ?, ?, ?, CURDATE(), CURTIME(), 'Sent')`,
      [title.trim(), safeHtml, recipientType, sentTo, userId, datePart, timePart || null]
    );

    res.json({ ok: true, status: 'Sent' });
  } catch (err) {
    console.error('createImmediate error:', err);
    res.status(500).json({ error: 'Failed to send notification' });
  }
});

/* -------- schedule -------- */
// POST /api/custom-notifications/schedule
// Body: { title, messageHtml, recipientType, recipientLabels?[], scheduledAt:'YYYY-MM-DD HH:mm:ss', schedulerNotes? }
router.post('/schedule', verifyToken, allowRoles('admin', 'superadmin'), async (req, res) => {
  try {
    const { id: userId } = req.user;
    const { title, messageHtml, recipientType, recipientLabels, scheduledAt } = req.body;

    if (!title || !title.trim()) return res.status(400).json({ error: 'Title is required' });
    if (!recipientType) return res.status(400).json({ error: 'Recipient type is required' });
    if (!scheduledAt) return res.status(400).json({ error: 'Schedule date & time is required' });

    const safeHtml = cleanHtml(messageHtml);
    const sentTo =
      Array.isArray(recipientLabels) && recipientLabels.length
        ? recipientLabels.join(', ')
        : (recipientType === 'all' ? 'All' : '(none)');

    const [datePart, timePart] = scheduledAt.split(' ');
    if (!datePart || !timePart) return res.status(400).json({ error: 'Invalid scheduledAt format' });

    await db.promise().query(
      `INSERT INTO custom_notifications
       (title, message_html, recipient_type, sent_to, user_id, date_sent, time_sent, send_status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled')`,
      [title.trim(), safeHtml, recipientType, sentTo, userId, datePart, timePart || null]
    );

    res.json({ ok: true, status: 'Scheduled' });
  } catch (err) {
    console.error('createScheduled error:', err);
    res.status(500).json({ error: 'Failed to schedule notification' });
  }
});

/* -------- scheduler table (admin/superadmin) -------- */
// GET /api/custom-notifications?dateFilter=last30&from=&to=&page=&limit=
router.get('/', verifyToken, allowRoles('superadmin'), async (req, res) => {
  const { dateFilter = 'last30', from, to, page = 1, limit = 50 } = req.query;

  const parsedPage = parseInt(page, 10);
  const parsedLimit = parseInt(limit, 10);
  const offset = (parsedPage - 1) * parsedLimit;

  let dateFrom = from;
  let dateTo = to;

  if (!from || !to) {
    const range = getDateRangeForFilter(dateFilter);
    if (range.start && range.end) {
      dateFrom = range.start;
      dateTo = range.end;
    }
  }

  try {
    const [countRows] = await db.promise().query(
      `SELECT COUNT(*) AS total
         FROM custom_notifications
        WHERE date_sent BETWEEN ? AND ?`,
      [dateFrom, dateTo]
    );
    const total = countRows[0]?.total || 0;

    const [rows] = await db.promise().query(
      `SELECT id, title, recipient_type, sent_to, user_id,
              date_sent, time_sent, send_status, created_at
         FROM custom_notifications
        WHERE date_sent BETWEEN ? AND ?
        ORDER BY
          CASE send_status WHEN 'Scheduled' THEN 0 ELSE 1 END,
          date_sent DESC, time_sent DESC, created_at DESC
        LIMIT ? OFFSET ?`,
      [dateFrom, dateTo, parsedLimit, offset]
    );

    res.json({ notifications: rows, total, page: parsedPage, limit: parsedLimit });
  } catch (err) {
    console.error('list error:', err);
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
});

/* -------- dashboard feed (all roles) -------- */
// GET /api/custom-notifications/feed?limit=10
// shows only Sent (so scheduled items appear when time arrives)
router.get('/feed', verifyToken, async (req, res) => {
  try {
    const { role } = req.user;
    const limit = Math.max(1, parseInt(req.query.limit || '20', 10));

    let where = "send_status='Sent'";
    if (role === 'admin') {
      where += " AND recipient_type IN ('all','admin')";
    } else if (role === 'middleman') {
      where += " AND recipient_type IN ('all','middleman')";
    } // superadmin sees all sent

    const [rows] = await db.promise().query(
      `SELECT id, title, message_html, recipient_type, sent_to, date_sent, time_sent, send_status, created_at
         FROM custom_notifications
        WHERE ${where}
        ORDER BY date_sent DESC, time_sent DESC, created_at DESC
        LIMIT ?`,
      [limit]
    );

    res.json({ data: rows });
  } catch (err) {
    console.error('feed error:', err);
    res.status(500).json({ error: 'Failed to load announcements' });
  }
});

module.exports = router;
