const express = require('express');
const router = express.Router();
const clientController = require('../controllers/clientController');
const { verifyToken, requireRole, checkServiceAccess } = require('../middleware/authMiddleware');
console.log('✅ typeof requireRole:', typeof requireRole); // should be function
console.log('✅ typeof verifyToken:', typeof verifyToken); // should be function
console.log('✅ typeof clientController.importClients:', typeof clientController.importClients); // should be function

router.get('/dashboard-stats', verifyToken, clientController.getDashboardStats);

// GET all clients (filtered by role)
router.get('/', verifyToken, clientController.getClients);
router.get('/cloud', verifyToken, requireRole('superadmin', 'admin', 'middleman'), clientController.getCloudClients);
router.get('/cerberus',
  verifyToken,
  requireRole('superadmin', 'admin', 'middleman'),
  clientController.getCerberusClients
);
router.get('/proxy', verifyToken, requireRole('superadmin', 'admin', 'middleman'), clientController.getProxyClients);
router.get('/storage', verifyToken, requireRole('superadmin', 'admin', 'middleman'), clientController.getStorageClients);
router.get('/varys', verifyToken, requireRole('superadmin', 'admin', 'middleman'), clientController.getVarysClients);

// clientRoutes.js
router.get('/expiring-clients', verifyToken, clientController.getExpiringClients);
router.post('/bulk-renew', verifyToken, requireRole('admin', 'superadmin'), clientController.bulkRenewClients);
router.get('/cancelled-clients', verifyToken, clientController.getCancelledClients);
router.patch('/bulk-restore', verifyToken, requireRole('admin', 'superadmin'), clientController.bulkRestoreClients);
router.patch('/bulk-delete', verifyToken, requireRole('superadmin'), clientController.bulkDeleteClients);
router.get('/deleted-clients', verifyToken, clientController.getDeletedClients);
router.patch('/bulk-delete-permanent', verifyToken, requireRole('superadmin'), clientController.bulkDeleteClientsPermanently);
// router.get('/report/:logicalClientId', verifyToken, clientController.getClientReport);
router.get('/report/:id', verifyToken, clientController.getClientReport);
router.delete('/delete-logical/:logicalClientId', verifyToken, clientController.deleteLogicalClient);






// clientRoutes.js
router.get('/names', verifyToken, clientController.getClientNames);
router.get('/services', verifyToken, clientController.getServices);
router.get('/plans/:serviceId', verifyToken, clientController.getServicePlans);
router.post('/plans', verifyToken, clientController.addPlan);
router.post('/import', verifyToken, requireRole('admin', 'superadmin'), clientController.importClients); // ✅ CORRECT

router.get('/:id', verifyToken, requireRole('admin', 'superadmin'), clientController.getClientById);
router.patch('/bulk-update', verifyToken, requireRole('admin', 'superadmin'), clientController.bulkUpdateClients);

router.post('/', verifyToken, requireRole('admin', 'superadmin'), clientController.addClient);

// POST a new client (admin/superadmin only)
router.post('/', verifyToken, requireRole('admin', 'superadmin'), clientController.addClient);

// PUT update a client (admin/superadmin only)
router.put('/:id', verifyToken, requireRole('admin', 'superadmin'), clientController.updateClient);

// DELETE (cancel) a client (superadmin only)
router.delete('/:id', verifyToken, requireRole('superadmin'), clientController.deleteClient);


// ✅ Dynamic service-based client fetch route (e.g., /clients/cerberus)
router.get('/:service',
  verifyToken,
  requireRole('admin', 'superadmin', 'middleman'),
  (req, res, next) => {
    const serviceKeyMap = {
      cerberus: 'is_cerberus',
      cloud: 'is_vps',
      proxy: 'is_proxy',
      storage: 'is_storage',
      varys: 'is_varys'
    };
    const flag = serviceKeyMap[req.params.service];
    if (!flag) return res.status(400).send("Invalid service");
    return checkServiceAccess(flag)(req, res, next);
  },
  clientController.getClients
);

module.exports = router;
