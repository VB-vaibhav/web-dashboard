const cron = require('node-cron');
const db = require('../config/db');

async function processDue() {
  const [rows] = await db.promise().query(
    `SELECT id FROM custom_notifications
      WHERE send_status='Scheduled'
        AND TIMESTAMP(date_sent, time_sent) <= NOW()`
  );

  for (const r of rows) {
    try {
      await db.promise().query(
        `UPDATE custom_notifications SET send_status='Sent' WHERE id=?`,
        [r.id]
      );
    } catch (e) {
      await db.promise().query(
        `UPDATE custom_notifications SET send_status='Failed' WHERE id=?`,
        [r.id]
      );
      console.error('Schedule → Sent failed', r.id, e);
    }
  }
}

// every minute
cron.schedule('* * * * *', processDue);
