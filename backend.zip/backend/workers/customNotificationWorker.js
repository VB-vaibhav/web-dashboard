// workers/customNotificationWorker.js
const db = require('../config/db');
const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc'); 
const tz = require('dayjs/plugin/timezone');
dayjs.extend(utc); dayjs.extend(tz);

const appTz = process.env.APP_TZ || 'Asia/Kolkata';

async function runOnce() {
  // “Now” in your app timezone
  const now = dayjs().tz(appTz);
  const nowDate = now.format('YYYY-MM-DD');
  const nowTime = now.format('HH:mm:ss');

  // All rows whose scheduled datetime is <= now
  const [rows] = await db.promise().query(`
    SELECT id FROM custom_notifications 
    WHERE send_status='Scheduled'
      AND (date_sent < ? OR (date_sent = ? AND time_sent <= ?))
  `, [nowDate, nowDate, nowTime]);

  if (!rows.length) return;

  // Mark these as Sent and stamp actual send date/time in your timezone
  await db.promise().query(`
    UPDATE custom_notifications
      SET send_status='Sent', date_sent=?, time_sent=?
    WHERE id IN (${rows.map(() => '?').join(',')})
  `, [nowDate, nowTime, ...rows.map(r => r.id)]);

  console.log(`[customNotifications] marked Sent: ${rows.map(r => r.id).join(', ')} at ${nowDate} ${nowTime}`);
  
}

module.exports = { runOnce };
