import React from 'react';

const MailSchedulerPage = () => {
  return (
    <div className="p-4 bg-white rounded shadow text-gray-800">
      <h2 className="text-xl font-semibold mb-2">MailSchedulerPage</h2>
      <p className="text-sm text-gray-600">This is a placeholder for reports.</p>
    </div>
  );
};

export default MailSchedulerPage;
